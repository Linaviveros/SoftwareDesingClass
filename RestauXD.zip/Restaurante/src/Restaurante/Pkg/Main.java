package Restaurante.Pkg;

import java.util.List;
import java.util.ArrayList;

public class Main {
	
		public static void main(String[] args) {
	        
			
	        Ingrediente ingrediente1 = new Ingrediente(" Leche", " 1 Litro", 10000.0, Proveedor.COLANTA, 558.0);
	        Ingrediente ingrediente2 = new Ingrediente(" Carne de res", " 1 Kilogramo", 13000.0, Proveedor.CARNESSABASTIAN, 156.0);

	        
	        List<String> listaIngredientes = new ArrayList<>();
	        listaIngredientes.add(ingrediente1.getNombre());
	        listaIngredientes.add(ingrediente2.getNombre());

	       
	        Receta receta1 = new Receta("Lasaña", 60.0, 4, listaIngredientes, "Una lasaña de carne");

	        
	        System.out.println("Receta:");
	        System.out.println(receta1);
	        System.out.println("\nIngredientes:");
	        System.out.println(ingrediente1);
	        System.out.println(ingrediente2);
	    	}
}


