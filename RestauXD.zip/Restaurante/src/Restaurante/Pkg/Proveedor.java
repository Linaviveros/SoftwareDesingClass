package Restaurante.Pkg;

public enum Proveedor {
	COLANTA, PASTOPASTO, COLACTEOS, ROA, CARNESSABASTIAN, SURTITODO,
}
